﻿#include <GL/glut.h>

void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Solid pyramid rendering
    glBegin(GL_TRIANGLES);

    // Define the base corners
    GLfloat A[] = { -3.5f, 0.0f, -2.0f };  // (−b/2, 0, −l/2)
    GLfloat B[] = { 3.5f, 0.0f, -2.0f };   // (b/2, 0, −l/2)
    GLfloat C[] = { 3.5f, 0.0f, 2.0f };    // (b/2, 0, l/2)
    GLfloat D[] = { -3.5f, 0.0f, 2.0f };   // (−b/2, 0, l/2)

    // Apex point
    GLfloat E[] = { 0.0f, 3.0f, 0.0f };    // (0, h, 0)

    // Base triangles
    glColor3f(0.6f, 0.4f, 0.2f); // Sandstone color
    glVertex3fv(A); glVertex3fv(B); glVertex3fv(C);
    glVertex3fv(A); glVertex3fv(C); glVertex3fv(D);

    // Side triangles
    glColor3f(0.8f, 0.7f, 0.3f);
    glVertex3fv(A); glVertex3fv(B); glVertex3fv(E);
    glVertex3fv(B); glVertex3fv(C); glVertex3fv(E);
    glVertex3fv(C); glVertex3fv(D); glVertex3fv(E);
    glVertex3fv(D); glVertex3fv(A); glVertex3fv(E);

    glEnd();

    // Outline the pyramid with black lines
    glColor3f(0.0f, 0.0f, 0.0f);  // Set color to black
    glLineWidth(2.0f);  // Set line width for better visibility

    glBegin(GL_LINES);
    // Base outline
    glVertex3fv(A); glVertex3fv(B);
    glVertex3fv(B); glVertex3fv(C);
    glVertex3fv(C); glVertex3fv(D);
    glVertex3fv(D); glVertex3fv(A);

    // Side edges
    glVertex3fv(A); glVertex3fv(E);
    glVertex3fv(B); glVertex3fv(E);
    glVertex3fv(C); glVertex3fv(E);
    glVertex3fv(D); glVertex3fv(E);
    glEnd();

    glFlush();
}

void init() {
    glEnable(GL_DEPTH_TEST);
    glMatrixMode(GL_PROJECTION);
    gluPerspective(45.0f, 1.0f, 1.0f, 50.0f);  // Adjust near and far planes
    glMatrixMode(GL_MODELVIEW);
    gluLookAt(0.0f, 5.0f, 12.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f); // Adjust camera position

    // Add lighting to make the pyramid visible
    GLfloat light_position[] = { 5.0f, 5.0f, 5.0f, 1.0f };
    GLfloat white_light[] = { 1.0f, 1.0f, 1.0f, 1.0f };
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, white_light);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(500, 500);
    glutCreateWindow("Egyptian Pyramid");
    init();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}
